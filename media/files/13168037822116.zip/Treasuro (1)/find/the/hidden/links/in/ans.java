import java.util.*;
class abc{
void main(){
System.out.println("Run");
System.out.println("the");
System.out.println("script");
System.out.println("to");
System.out.println("get");
System.out.println("the");
System.out.println("answer");
}
}
